//
//  Fireblocks.h
//  Fireblocks
//
//  Created by Dudi Shani-Gabay on 18/06/2023.
//

#import <Foundation/Foundation.h>
#import <FireblocksSDK/ObjectiveCUtils.h>

//! Project version number for Fireblocks.
FOUNDATION_EXPORT double FireblocksSDKVersionNumber;

//! Project version string for Fireblocks.
FOUNDATION_EXPORT const unsigned char FireblocksSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Fireblocks/PublicHeader.h>


